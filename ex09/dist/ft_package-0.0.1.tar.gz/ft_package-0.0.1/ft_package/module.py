"""Module containing utility functions for ft_package."""


def count_in_list(lst, value):
    """Count occurrences of a value in a list.

    Takes a list and a value, and returns how many times that value
    appears in the list.
    """
    return lst.count(value)
